export const USER = {
  id: '',
	userName: '',
  password: '',
	rePassword: '',
	email: '',
	photo: '',
	contentType: '',
  active: ''
};

export const ERRORS = {
	id: '',
	userName: '',
  password: '',
	rePassword: '',
	email: '',
	photo: '',
	contentType: '',
  active: ''
};